package com.trainticket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyController {
    @Autowired
    Ticket ticket;
    Passenger passenger;
    @RequestMapping("/login")

    public ModelAndView login(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
    {


       int total= (int) ticket.calculateTotalTicketPrice();
       int newtotal= (int) ticket.calcPassengerFare(passenger );
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("a",total);
        modelAndView.addObject("newtotal",newtotal);
        modelAndView.setViewName("Ticket.jsp");
        return modelAndView;
    }
}
